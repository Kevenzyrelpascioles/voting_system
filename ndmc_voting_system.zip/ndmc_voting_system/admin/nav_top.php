	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="brand">
		<img src="images/NDMC logo.jpg" width="60" height="60">
 	</a>
 	</a>
	<a class="brand">
	 <h2>NDMC Voting System</h2>
	 <div class="chmsc_nav"><font size="4" color="white"> Notre Dame of Midsayap College</font></div>
 	</a>

	<?php include('head.php'); ?>
 
 
	</div>
	</div>
	</div>

	