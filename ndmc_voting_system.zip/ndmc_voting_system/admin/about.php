<h1><font color="gray">Online Voting System</font></h1>
</br>
<font color="#555">
<p>Notre Dame of Midsayap College</p>
<p>Develop By:</p>
</font>
</br>
<div id="accordion2" class="accordion">
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseOne" data-parent="#accordion2" data-toggle="collapse">Keven Pascioles</a>
</div>
<div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
<div class="accordion-inner"> 
<p><font color="gray">Position:&nbsp;Programmer</font></p>
<p><font color="gray">FirstName:&nbsp;Keven</font></p>
<p><font color="gray">LastName:&nbsp;Pascioles</font></p>
<p><font color="gray">Age:&nbsp;21</font></p>
<p><font color="gray">Address:&nbsp;Libungan</font></p>
<div class="user_image"><img src="project_member/Keven.jpg" width="200" height="250"></div>
</div>
</div>
</div>


<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseTwo" data-parent="#accordion2" data-toggle="collapse">Cris Lee Arcenal</a>
</div>
<div id="collapseTwo" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Designer</font></p>
<p><font color="gray">FirstName:&nbsp;Cris Lee</font></p>
<p><font color="gray">LastName:&nbsp;Arcenal</font></p>
<p><font color="gray">Age:&nbsp;22</font></p>
<p><font color="gray">Address:&nbsp;Midsayap</font></p>
<div class="user_image"><img src="project_member/Cris.jpg" width="200" height="250"></div>
</div>
</div>
</div>

