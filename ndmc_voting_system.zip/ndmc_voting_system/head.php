
	
	<div class="top_date"> 
			<font color="white">Date is:&nbsp;
			<script type="text/javascript" language="JavaScript">
			var calendarDate = getCalendarDate();
			document.write(calendarDate);
			</script>
			</font>
		</div>
		
		
	    <div class="hero-unit-clock">
		</br>
			<form name="clock">
			<font color="white">Time is:</font>&nbsp;<input type="submit" class="trans" name="face" value="">
			</form>
			  </div>
			  
		

	 
	

	
